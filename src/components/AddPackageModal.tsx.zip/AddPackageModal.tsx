import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  Image,
  TouchableOpacity,
  StyleSheet,
  Modal,
  ScrollView,
  Dimensions,
  ActivityIndicator,
  PermissionsAndroid,
  Platform,
  Alert,
} from 'react-native';
import ImageCropPicker from 'react-native-image-crop-picker';
import RNFS from 'react-native-fs';
import { Formik } from 'formik';
import { COLORS, FONTS, IMAGES } from '../assets';
import { KeyboardScroll } from './KeyboardScroll';
import { InputPicker } from './InputPicker';
import { isIPad } from '../utilities/securestorage';
import { ShipListModal } from './ShipListModal';
import { open } from './CameraController';
import { LoadImage } from './LoadImage';
import { PackageType } from './PackageList';
import {
  CarrierObj,
  PackageConditionType,
  PackageStatusObj,
  usePackageContext,
} from '../contexts/packagecontext';
import { deleteImg, uploadImg } from '../utilities/ApiCalls';
import { useAuth } from '../contexts';
import tnv from 'tracking-number-validation';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

// ─────────────────────────────────────────────────────────────
// 🔑 HARDCODED FOR TESTING — move to react-native-config later
// ─────────────────────────────────────────────────────────────
const VISION_API_KEY = 'AIzaSyBcmJZ6P3UeqjpX8biK0UMdogjnNN9PG88';
const VISION_URL = `https://vision.googleapis.com/v1/images:annotate?key=${VISION_API_KEY}`;


// ─────────────────────────────────────────────────────────────
//  CLOUD VISION
// ─────────────────────────────────────────────────────────────
const scanWithCloudVision = async (
  imagePath: string,
): Promise<{ text: string; confidence: number }> => {
  const cleanPath = imagePath.replace('file://', '');
  const base64Image = await RNFS.readFile(cleanPath, 'base64');

  const response = await fetch(VISION_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      requests: [
        {
          image: { content: base64Image },
          features: [{ type: 'DOCUMENT_TEXT_DETECTION' }],
          imageContext: {
            languageHints: ['en'], 
            textDetectionParams: {
              enableTextDetectionConfidenceScore: true,
            },
          },
        },
      ],
    }),
  });

  const data = await response.json();
  if (data.error) throw new Error(data.error.message ?? 'Vision API error');

  const annotation = data.responses?.[0]?.fullTextAnnotation;
  const text: string = annotation?.text ?? '';
  const confidence: number = annotation?.pages?.[0]?.confidence ?? 0;

  console.log(`[Vision] confidence=${(confidence * 100).toFixed(1)}%`);
  console.log(`[Vision] raw text:\n${text}`);

  return { text, confidence };
};

// ─────────────────────────────────────────────────────────────
//  TRACKING NUMBER EXTRACTOR
// ─────────────────────────────────────────────────────────────
const extractTrackingNumber = (text: string): string | null => {
  if (!text) return null;
  const cleanText = text.replace(/\n/g, ' ');

  // 1. Explicit label: "TRACKING ID:", "AWB:", etc.
  const labelMatch = cleanText.match(
    /(?:TRACKING(?:\s*(?:ID|NUMBER|NO|#))?|AWB|WAYBILL)[:\s#]*([A-Z0-9]{8,30})/i,
  );
  if (labelMatch?.[1]) return labelMatch[1];

  // 2. TBA Amazon numbers
  const words = cleanText.split(/\s+/);
  const tbaMatch = words.find(w => /^TBA[A-Z0-9]{9,}$/i.test(w));
  if (tbaMatch) return tbaMatch;

  // 3. FedEx 12/15/20 digit
  const fedexMatch = cleanText.match(/\b([0-9]{12}|[0-9]{15}|[0-9]{20})\b/);
  if (fedexMatch?.[1]) return fedexMatch[1];

  // 4. UPS 1Z
  const upsMatch = cleanText.match(/\b(1Z[A-Z0-9]{16})\b/i);
  if (upsMatch?.[1]) return upsMatch[1];

  // 5. USPS 20–22 digit
  const uspsMatch = cleanText.match(/\b([0-9]{20,22})\b/);
  if (uspsMatch?.[1]) return uspsMatch[1];

  // 6. DHL 10 digit
  const dhlMatch = cleanText.match(/\b([0-9]{10})\b/);
  if (dhlMatch?.[1]) return dhlMatch[1];

  return null;
};

// ─────────────────────────────────────────────────────────────
//  TYPES
// ─────────────────────────────────────────────────────────────
interface packageImages {
  image1: string;
  image2: string;
  image3: string;
}

export interface packageOption {
  trackingId: string;
  type: PackageType;
  condition: PackageConditionType;
  carrier: CarrierObj;
  message: string;
  imagesObj: packageImages[];
  ocrText?: string;
}

interface packageModalProps {
  isVisible: boolean;
  onSetVisible: () => void;
  onSubmitPackage: (value: packageOption) => void;
  packageValue: any;
  setPackageValue: (val: any) => void;
  // ── NEW: parent listens for OCR text so BottomDrawer can use it ──
  onOcrTextReady?: (text: string) => void;
}

// ─────────────────────────────────────────────────────────────
//  COMPONENT
// ─────────────────────────────────────────────────────────────
const AddPackageModal: React.FC<packageModalProps> = ({
  isVisible,
  onSetVisible,
  onSubmitPackage,
  packageValue,
  setPackageValue,
  onOcrTextReady, // ← parent passes this to receive OCR text
}) => {
  const [isModalVisible, setModalVisible] = useState(false);
  const [pickerType, setPickerType] = useState('');
  const [trackingId, setTrackingId] = useState('');
  const [status, setStatus] = useState<PackageType | null>(null);
  const [type, setType] = useState<PackageType | null>(null);
  const [condition, setCondition] = useState<PackageConditionType | null>(null);
  const [carrier, setCarrier] = useState<CarrierObj | null>(null);
  const [message, setMessage] = useState('');
  const [ocrText, setOcrText] = useState('');
  const [isOcrScanning, setIsOcrScanning] = useState(false);
  const [ocrImage, setOcrImage] = useState('');
const [ocrImageUrl, setOcrImageUrl] = useState('');

  // ── Camera permission ──────────────────────────────────────
  const requestCameraPermission = async (): Promise<boolean> => {
    if (Platform.OS === 'android') {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.CAMERA,
          {
            title: 'Camera Permission',
            message: 'App needs camera access to scan package labels',
            buttonPositive: 'OK',
          },
        );
        return granted === PermissionsAndroid.RESULTS.GRANTED;
      } catch {
        return false;
      }
    }
    return true;
  };

  // ── Open camera and scan ───────────────────────────────────
const openOCRAndScan = async () => {
  const hasPermission = await requestCameraPermission();
  if (!hasPermission) return;

  try {
    const image = await ImageCropPicker.openCamera({
      cropping: false,
      mediaType: 'photo',
      compressImageQuality: 1,
    });

    console.log('📷 OCR Image:', image.path);

    // ✅ STEP 1: OCR FIRST
    await handleCloudVisionOCR(image.path);

    // ✅ STEP 2: UPLOAD AFTER OCR
    let imgData = new FormData();
    imgData.append('image', {
      name: 'ocr.jpg',
      type: 'image/jpeg',
      uri: image.path,
    });

    setIsImageUploading(true);
    setImageLoading(1);

    const imgRes = await uploadImg(user, imgData);

    setImageLoading(0);
    setIsImageUploading(false);

    if (imgRes?.image_url) {
      setImagesObj(prev => ({
        ...prev,
        image1dummy: image.path,
        image1: imgRes.image_url,
      }));

      setError(prev => ({ ...prev, isImages: false }));
    }

  } catch (err: any) {
    if (err?.code === 'E_PICKER_CANCELLED') return;
    console.log(err);
  }
};
  // ── Cloud Vision OCR ───────────────────────────────────────
  const handleCloudVisionOCR = async (imagePath: string) => {
    if (!imagePath) return;
    setIsOcrScanning(true);

    const finalPath =
      Platform.OS === 'ios' && !imagePath.startsWith('file://')
        ? `file://${imagePath}`
        : imagePath;

    try {
      const { text, confidence } = await scanWithCloudVision(finalPath);

      if (confidence < 0.75) {
        Alert.alert(
          'Poor Scan Quality',
          'Image is blurry or poorly lit. Would you like to retake?',
          [
            { text: 'Retake', onPress: openOCRAndScan },
            { text: 'Use Anyway', onPress: () => processOcrText(text) },
          ],
        );
        return;
      }

      processOcrText(text);
    } catch (err: any) {
      console.error('[Vision Error]', err);
      Alert.alert(
        'Scan Failed',
        err?.message ?? 'Could not read the label. Please try again.',
        [{ text: 'OK' }],
      );
    } finally {
      setIsOcrScanning(false);
    }
  };

  // ── Process OCR result ─────────────────────────────────────
  const processOcrText = (text: string) => {
    console.log('[OCR] Processing text:', text);

    // Save locally for submission
    setOcrText(text);

    // ✅ KEY: notify parent so BottomDrawer gets the text immediately
    if (onOcrTextReady) {
      onOcrTextReady(text);
    }

    // Extract tracking number
    const trackingNumber = extractTrackingNumber(text);
    if (trackingNumber) {
      console.log('✅ Tracking Number:', trackingNumber);
      setTrackingId(trackingNumber);
      setError(prev => ({ ...prev, isTrackingId: false }));
    } else {
      console.log('❌ Tracking number not found');
    }
  };

  // ── Images / form state ────────────────────────────────────
  const [imagesObj, setImagesObj] = useState({
    image1: '',
    image2: '',
    image3: '',
    image1dummy: '',
    image2dummy: '',
    image3dummy: '',
  });

  const [error, setError] = useState({
    isTrackingId: false,
    isStatus: false,
    isType: false,
    isCondition: false,
    isImages: false,
  });

  const { user } = useAuth();

  useEffect(() => {
    if (packageValue?.trackingId) {
      __DEV__ && console.log('packageValue', packageValue);
      const { carrier, condition, imagesObj, trackingId, type, status, message } =
        packageValue;
      setTrackingId(trackingId);
      setStatus(status);
      setType(type);
      setCondition(condition);
      setCarrier(carrier);
      setImagesObj(imagesObj);
      setMessage(message);
    } else {
      setTrackingId('');
      setImagesObj({
        image1: '',
        image2: '',
        image3: '',
        image1dummy: '',
        image2dummy: '',
        image3dummy: '',
      });
    }
  }, [packageValue]);

  const [imageLoading, setImageLoading] = useState(0);
  const [isImageUploading, setIsImageUploading] = useState(false);

  const selectMedia = async (key: number) => {
    open(async (response: any) => {
      __DEV__ && console.log('Responsee==>', response);
      if (response.path) {
        let imgData = new FormData();
        imgData.append('image', {
          name: 'image',
          type: 'image/jpeg',
          uri: response.path,
        });
        setIsImageUploading(true);
        setImageLoading(key);
        const imgRes = await uploadImg(user, imgData);
        setImageLoading(0);
        if (imgRes?.image_url) setIsImageUploading(false);
        __DEV__ && console.log('image res==', imgRes);
        setError(prev => ({ ...prev, isImages: false }));
        if (key === 1) {
          setImagesObj(prev => ({ ...prev, image1dummy: response.path, image1: imgRes?.image_url }));
        } else if (key === 2) {
          setImagesObj(prev => ({ ...prev, image2dummy: response.path, image2: imgRes?.image_url }));
        } else if (key === 3) {
          setImagesObj(prev => ({ ...prev, image3dummy: response.path, image3: imgRes?.image_url }));
        }
      }
    });
  };

  const checkValidation = () => {
    if (!trackingId) { setError(prev => ({ ...prev, isTrackingId: true })); return true; }
    else if (!type?.name) { setError(prev => ({ ...prev, isType: true })); return true; }
    else if (!status?.name) { setError(prev => ({ ...prev, isStatus: true })); return true; }
    else if (!condition?.name) { setError(prev => ({ ...prev, isCondition: true })); return true; }
    else if (!imagesObj?.image1 && !imagesObj?.image2 && !imagesObj?.image3) {
      setError(prev => ({ ...prev, isImages: true })); return true;
    }
    return false;
  };

  const clearData = () => {
    setPickerType('');
    setType(null);
    setCondition(null);
    setCarrier(null);
    setStatus(null);
    setImagesObj({ image1: '', image2: '', image3: '', image1dummy: '', image2dummy: '', image3dummy: '' });
    setMessage('');
    setOcrText('');
    setPackageValue(null);
    setError({ isTrackingId: false, isStatus: false, isType: false, isCondition: false, isImages: false });
  };

  const onSubmit = async () => {
    const isValid = await checkValidation();
    __DEV__ && console.log('-is valid==', isValid);
    if (!isValid) {
      const obj: packageOption = packageValue?.id
        ? { trackingId, type: type!, status, condition: condition!, carrier: carrier!, message, imagesObj, id: packageValue.id, ocrText }
        : { trackingId, type: type!, status, condition: condition!, carrier: carrier!, message, imagesObj, ocrText };

      __DEV__ && console.log('obj==', obj);
      onSetVisible();
      setTrackingId('');
      setStatus(null);
      setCondition(null);
      setCarrier(null);
      setMessage('');
      setImagesObj({ image1: '', image2: '', image3: '', image1dummy: '', image2dummy: '', image3dummy: '' });
      onSubmitPackage(obj);
      clearData();
    }
  };

  const onPickerClick = (type: string) => {
    setModalVisible(!isModalVisible);
    setPickerType(type);
  };

  const onDeleteImg = async (img: string) => {
    const data = { image_name: img };
    const deleteRes = await deleteImg(user, data);
    __DEV__ && console.log('deleteRes', deleteRes);
  };

  const { carriers } = usePackageContext();

  const populateCarrier = (id: any) => {
    if (id?.startsWith('JD')) return;
    const courier = tnv.getCourier(id);
    let carrier;
    if (!courier?.length) {
      carrier = carriers?.find(c => c.name === 'Other');
    } else {
      if (courier[0] === 'fedex') carrier = carriers?.find(c => c.name === 'FedEx');
      else if (courier[0] === 'amazon') carrier = carriers?.find(c => c.name === 'Amazon');
      else if (courier[0] === 'usps') carrier = carriers?.find(c => c.name === 'US Postal Service');
      else if (courier[0] === 'ups') carrier = carriers?.find(c => c.name === 'UPS');
      else if (courier[0] === 'dhl') carrier = carriers?.find(c => c.name === 'DHL');
      else carrier = carriers?.find(c => c.name === 'Other');
    }
    return carrier || { id: 1, name: 'Other' };
  };

  useEffect(() => {
    if (trackingId.length > 0) {
      const getCarrier: any = populateCarrier(trackingId);
      setCarrier(getCarrier);
    } else {
      setCarrier(null);
    }
  }, [trackingId]);

  return isVisible ? (
    <View style={styles.modalContainer}>
      <View style={styles.modalContent}>
        <TouchableOpacity
          style={isIPad ? styles.crossViewI : styles.crossView}
          disabled={isImageUploading}
          onPress={() => { onSetVisible(); setPackageValue(null); clearData(); }}>
          <Image source={IMAGES.close} style={isIPad ? styles.closeImgI : styles.closeImg} />
        </TouchableOpacity>

        <ShipListModal
          visible={isModalVisible}
          onClose={() => setModalVisible(false)}
          activeTab={pickerType}
          getValue={(val: PackageType | PackageConditionType | CarrierObj) => {
            if (pickerType === 'Type') setType(val as PackageType);
            else if (pickerType === 'Status') setStatus(val as PackageType);
            else if (pickerType === 'Condition') setCondition(val as PackageConditionType);
            else if (pickerType === 'Carrier') setCarrier(val as CarrierObj);
          }}
          setInitialVals={!packageValue?.trackingId && { type, setType, condition, setCondition, carrier, setCarrier, status, setStatus }}
        />

        <KeyboardAwareScrollView contentContainerStyle={{}}>
          <TouchableOpacity activeOpacity={1}>
            {/* Scan Button */}
            <TouchableOpacity
              onPress={openOCRAndScan}
              disabled={isOcrScanning}
              style={[styles.ocrBtn, isOcrScanning && styles.ocrBtnDisabled]}>
              {isOcrScanning ? (
                <ActivityIndicator size={isIPad ? 'large' : 'small'} color="#1B77AC" />
              ) : (
                <Image source={IMAGES.Ocr} style={{ height: isIPad ? 50 : 30, width: isIPad ? 50 : 35, resizeMode: 'contain' }} />
              )}
              <Text style={styles.ocrTxt}>{isOcrScanning ? 'Scanning...' : 'Scan Label (OCR)'}</Text>
            </TouchableOpacity>

            <InputPicker isPicker={false} maxLength={30} isQrCode={true} placeholder={'Tracking ID*'} style={{}} onPickerClick={() => {}} pickerValue={trackingId}
              onChangeText={val => { setTrackingId(val.trimStart()); setError(prev => ({ ...prev, isTrackingId: false })); }} />
            {error?.isTrackingId && <Text style={styles.errorMsg}>Please enter Tracking ID</Text>}

            <InputPicker isPicker={true} isQrCode={false} placeholder={'Type'} style={{}}
              onPickerClick={() => { onPickerClick('Type'); setError(prev => ({ ...prev, isStatus: false })); }}
              pickerValue={type?.name} onChangeText={() => {}} />
            {error?.isType && <Text style={styles.errorMsg}>Please Select Package Type</Text>}

            <InputPicker isPicker={true} isQrCode={false} placeholder={'Status'} style={{}}
              onPickerClick={() => { onPickerClick('Status'); setError(prev => ({ ...prev, isStatus: false })); }}
              pickerValue={status?.name} onChangeText={() => {}} />
            {error?.isStatus && <Text style={styles.errorMsg}>Please Select Package Status</Text>}

            <InputPicker isPicker={true} isQrCode={false} placeholder={'Condition'} style={{}}
              onPickerClick={() => onPickerClick('Condition')} pickerValue={condition?.name} onChangeText={() => {}} />
            {error?.isCondition && <Text style={styles.errorMsg}>Please Select Package Condition</Text>}

            <InputPicker isPicker={true} isQrCode={false} placeholder={'Carrier'} style={{}}
              onPickerClick={() => onPickerClick('Carrier')} pickerValue={carrier?.name} onChangeText={() => {}} />

            <InputPicker isPicker={false} isQrCode={false} placeholder={'Message'} style={{}}
              onPickerClick={() => {}} pickerValue={message} onChangeText={val => setMessage(val)} />

            {error?.isImages && <Text style={[styles.errorMsg, { marginTop: 20 }]}>Add at least one photo.</Text>}

            <View style={{ marginTop: isIPad ? 30 : 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-evenly' }}>
              {/* Image 1 */}
              <View>
                <TouchableOpacity style={{ opacity: isImageUploading ? 0.5 : 1 }} onPress={() => selectMedia(1)} disabled={isImageUploading}>
                  {imageLoading === 1 ? <ActivityIndicator style={styles.imgGrey} size="small" color="#61B3E4" /> : (
                    <Image resizeMode="contain" style={imagesObj.image1dummy ? styles.imgGrey : styles.imgGreyy}
                      source={imagesObj.image1dummy ? { uri: imagesObj.image1dummy } : IMAGES.camera} />
                  )}
                </TouchableOpacity>
                {imagesObj.image1dummy ? (
                  <TouchableOpacity onPress={() => { onDeleteImg(imagesObj.image1); setImagesObj(prev => ({ ...prev, image1: '', image1dummy: '' })); }}
                    style={{ alignSelf: 'center', marginTop: 10 }} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
                    <Image style={{ height: isIPad ? 35 : 17, width: isIPad ? 35 : 17 }} source={IMAGES.delete} />
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity disabled={isImageUploading} style={[styles.addView, { opacity: isImageUploading ? 0.5 : 1 }]} onPress={() => selectMedia(1)}>
                    <Text style={styles.addTxt}>Add Photo</Text>
                  </TouchableOpacity>
                )}
              </View>
              {/* Image 2 */}
              <View style={{ marginLeft: 10 }}>
                <TouchableOpacity style={{ opacity: isImageUploading ? 0.5 : 1 }} onPress={() => selectMedia(2)} disabled={isImageUploading}>
                  {imageLoading === 2 ? <ActivityIndicator style={styles.imgGrey} size="small" color="#61B3E4" /> : (
                    <Image resizeMode="contain" style={imagesObj.image2dummy ? styles.imgGrey : styles.imgGreyy}
                      source={imagesObj.image2dummy ? { uri: imagesObj.image2dummy } : IMAGES.camera} />
                  )}
                </TouchableOpacity>
                {imagesObj.image2dummy ? (
                  <TouchableOpacity onPress={() => { onDeleteImg(imagesObj.image2); setImagesObj(prev => ({ ...prev, image2: '', image2dummy: '' })); }}
                    style={{ alignSelf: 'center', marginTop: 10 }} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
                    <Image style={{ height: isIPad ? 35 : 17, width: isIPad ? 35 : 17 }} source={IMAGES.delete} />
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity disabled={isImageUploading} style={[styles.addView, { opacity: isImageUploading ? 0.5 : 1 }]} onPress={() => selectMedia(2)}>
                    <Text style={styles.addTxt}>Add Photo</Text>
                  </TouchableOpacity>
                )}
              </View>
              {/* Image 3 */}
              <View style={{ marginLeft: 10 }}>
                <TouchableOpacity onPress={() => selectMedia(3)} disabled={isImageUploading} style={{ opacity: isImageUploading ? 0.5 : 1 }}>
                  {imageLoading === 3 ? <ActivityIndicator style={styles.imgGrey} size="small" color="#61B3E4" /> : (
                    <Image resizeMode="contain" style={imagesObj.image3dummy ? styles.imgGrey : styles.imgGreyy}
                      source={imagesObj.image3dummy ? { uri: imagesObj.image3dummy } : IMAGES.camera} />
                  )}
                </TouchableOpacity>
                {imagesObj.image3dummy ? (
                  <TouchableOpacity onPress={() => { onDeleteImg(imagesObj.image3); setImagesObj(prev => ({ ...prev, image3: '', image3dummy: '' })); }}
                    style={{ alignSelf: 'center', marginTop: 10 }} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
                    <Image style={{ height: isIPad ? 35 : 17, width: isIPad ? 35 : 17 }} source={IMAGES.delete} />
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity disabled={isImageUploading} style={[styles.addView, { opacity: isImageUploading ? 0.5 : 1 }]} onPress={() => selectMedia(3)}>
                    <Text style={styles.addTxt}>Add Photo</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          </TouchableOpacity>
        </KeyboardAwareScrollView>

        <View style={[styles.direction, { justifyContent: 'space-between' }]}>
          <TouchableOpacity
            style={[isIPad ? styles.clearBtnI : styles.clearBtn, { opacity: isImageUploading ? 0.5 : 1 }]}
            disabled={isImageUploading}
            onPress={() => { setTrackingId(''); setPackageValue(null); clearData(); }}>
            <Text style={isIPad ? styles.btnTxtI : styles.btnTxt}>Clear</Text>
          </TouchableOpacity>
          <TouchableOpacity
            disabled={isImageUploading}
            style={[isIPad ? styles.clearBtnI : styles.clearBtn, { backgroundColor: '#FDBE6F', marginLeft: 10, opacity: isImageUploading ? 0.5 : 1 }]}
            onPress={onSubmit}>
            <Text style={isIPad ? styles.btnTxtI : styles.btnTxt}>Save</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  ) : <></>;
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  errorMsg: { fontSize: isIPad ? 20 : 14, fontFamily: FONTS.PoppinsRegular, color: 'red', marginLeft: 30 },
  ocrBtn: { flexDirection: 'row', alignItems: 'center', alignSelf: 'center', gap: 6, borderWidth: 1, borderColor: 'lightgrey', paddingVertical: 6, paddingHorizontal: 12, borderRadius: 8, marginBottom: 4 },
  ocrBtnDisabled: { opacity: 0.5 },
  ocrTxt: { fontSize: isIPad ? 18 : 15, fontFamily: FONTS.PoppinsSemiBold, color: '#1B77AC' },
  modalContainer: { position: 'absolute', bottom: 0, width: '100%', zIndex: 1, height: '100%', justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.5)' },
  modalContent: { backgroundColor: '#FFFFFF', borderTopLeftRadius: 20, borderTopRightRadius: 20, height: 'auto', paddingBottom: 10, maxHeight: '95%' },
  crossView: { height: 48, width: 48, borderRadius: 24, justifyContent: 'center', alignItems: 'center', backgroundColor: '#F4F4F4', alignSelf: 'flex-end', marginRight: 10, marginTop: 10 },
  crossViewI: { height: 65, width: 65, borderRadius: 32, justifyContent: 'center', alignItems: 'center', backgroundColor: '#F4F4F4', alignSelf: 'flex-end', marginRight: 10, marginTop: 10 },
  closeImg: { height: 10, width: 10, tintColor: 'black' },
  closeImgI: { height: 20, width: 20, tintColor: 'black' },
  direction: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 30, marginVertical: isIPad ? 30 : 16 },
  clearBtn: { height: 50, borderRadius: 26, backgroundColor: '#1B77AC', justifyContent: 'center', alignItems: 'center', flex: 1 },
  clearBtnI: { height: 75, borderRadius: 40, backgroundColor: '#1B77AC', justifyContent: 'center', alignItems: 'center', flex: 1 },
  drawerContainer: { position: 'absolute', bottom: 0, width: '100%', flexDirection: 'row', justifyContent: 'space-around', paddingVertical: 10, borderTopLeftRadius: 20, borderTopRightRadius: 20 },
  button: { flex: 1, marginHorizontal: 10, paddingVertical: 15, borderRadius: 25, alignItems: 'center' },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  trckId: { color: '#989898', fontSize: 14, fontFamily: FONTS.PoppinsRegular, flex: 1 },
  codeImg: { height: 20, width: 20 },
  lineView: { marginHorizontal: 30, height: 1, backgroundColor: '#98989850', marginTop: 10 },
  imgGrey: { height: isIPad ? 200 : 100, width: isIPad ? 200 : 100, borderRadius: 20 },
  imgGreyy: { height: isIPad ? 200 : 50, width: isIPad ? 200 : 50, alignSelf: 'center', borderRadius: 20 },
  addView: { height: 32 },
  addTxt: { fontSize: isIPad ? 20 : 14, fontFamily: FONTS.PoppinsRegular, color: '#1B77AC', textAlign: 'center', marginTop: 10 },
  btnTxt: { color: 'white', fontSize: 16, fontFamily: FONTS.PoppinsSemiBold },
  btnTxtI: { color: 'white', fontSize: isIPad ? 25 : 20, fontFamily: FONTS.PoppinsSemiBold },
});

export { AddPackageModal };
