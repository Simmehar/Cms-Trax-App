import React, { ReactNode, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Dimensions,
  DeviceEventEmitter,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { FONTS, IMAGES } from '../assets';
import { InputPicker } from './InputPicker';
import { ShipListModal } from './ShipListModal';
import { CheckIpad, isIPad } from '../utilities/securestorage';
import { DeparmentObj, RecipentObj, Ships, usePackageContext } from '../contexts/packagecontext';
import { sortTrackingNumber } from '../functions/SortTrackingNumber';
import { recipientSearchApi } from '../utilities/ApiCalls';

let isPad = CheckIpad();
const screenhight = Dimensions.get('window').height;


const levenshtein = (a: string, b: string): number => {
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const dp: number[][] = Array.from({ length: a.length + 1 }, (_, i) =>
    Array.from({ length: b.length + 1 }, (_, j) =>
      i === 0 ? j : j === 0 ? i : 0,
    ),
  );
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      dp[i][j] =
        a[i - 1] === b[j - 1]
          ? dp[i - 1][j - 1]
          : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
    }
  }
  return dp[a.length][b.length];
};

const editSimilarity = (a: string, b: string): number => {
  if (!a || !b) return 0;
  return 1 - levenshtein(a, b) / Math.max(a.length, b.length);
};

const norm = (t: any): string =>
  t ? t.toLowerCase().replace(/[^a-z]/g, '') : '';

const extractAllTokens = (ocrText: string): string[] => {
  const segments = ocrText
    .split(/[\n\/\|,;]+/)
    .map(s => s.trim())
    .filter(Boolean);
  const allTokens: string[] = [];
  for (const seg of segments) {
    allTokens.push(seg);
    const words = seg.split(/\s+/).filter(Boolean);
    allTokens.push(...words);
    for (let i = 0; i < words.length - 1; i++) {
      allTokens.push(`${words[i]} ${words[i + 1]}`);
    }
    for (let i = 0; i < words.length - 2; i++) {
      allTokens.push(`${words[i]} ${words[i + 1]} ${words[i + 2]}`);
    }
  }
  return [...new Set(allTokens)];
};


const JUNK_WORDS = new Set([
  'tracking', 'id', 'casino', 'cruise', 'ship', 'fort',
  'lauderdale', 'street', 'united', 'states', 'celebrity',
  'summit', 'beyond', 'amazon', 'amazoncom', 'tbadd', 'nw',
  'st', 'fl', 'ky', 'trace', 'th', 'llc', 'inc', 'corp',
  'oakland', 'park', 'lane',
]);

const extractNameCandidates = (ocrText: string): string[] => {

  const preCleaned = ocrText.replace(/[()[\]{}<>]/g, ' ');

  const segments = preCleaned
    .split(/[\n\/\|,;]+/)
    .map(s => s.trim())
    .filter(Boolean);

  const candidates: string[] = [];

  for (const seg of segments) {
    const words = seg.split(/\s+/).filter(w => {
      const clean = w.replace(/[^a-zA-Z]/g, '');
      return (
        clean.length >= 2 &&
        !/\d/.test(w) &&
        !JUNK_WORDS.has(clean.toLowerCase())
      );
    }).map(w => w.replace(/[^a-zA-Z\s]/g, ''));


    for (let i = 0; i < words.length - 1; i++) {
      candidates.push(`${words[i]} ${words[i + 1]}`);
    }

    for (let i = 0; i < words.length - 2; i++) {
      candidates.push(`${words[i]} ${words[i + 1]} ${words[i + 2]}`);
    }
  }

  return [...new Set(candidates)];
};

const extractLocation = (ocrText: string): string | null => {
  if (!ocrText) return null;

  const lines = ocrText.split(/\n/).map(l => l.trim()).filter(Boolean);
  const flat = ocrText.replace(/\n/g, ' ');


  const deckCabinCombo = flat.match(
    /\bDeck\s*[:#]?\s*([A-Z0-9]+)[,\s]+(?:Cabin|Stateroom|Room)\s*[:#]?\s*([A-Z0-9]+)/i,
  );
  if (deckCabinCombo) {
    return `Deck ${deckCabinCombo[1]} Cabin ${deckCabinCombo[2]}`;
  }

  const cabinMatch = flat.match(
    /(?:Cabin|Stateroom|Room|Cabin\s*#|Stateroom\s*#|Room\s*#)\s*[:#]?\s*([A-Z]?\d{1,5}[A-Z]?)/i,
  );
  if (cabinMatch) {
    const label = cabinMatch[0].match(/^(Cabin|Stateroom|Room)/i)?.[1] ?? 'Cabin';
    return `${label} ${cabinMatch[1]}`;
  }


  const deckMatch = flat.match(
    /\bDeck\s*[:#]?\s*([A-Z]?\d{1,3}[A-Z]?)\b/i,
  );
  if (deckMatch) {
    return `Deck ${deckMatch[1]}`;
  }


  for (const line of lines) {
    const bareMatch = line.match(/^\s*([A-Z]?\d{4}[A-Z]?)\s*$/i);
    if (bareMatch) {
      const n = parseInt(bareMatch[1], 10);
      if (!isNaN(n) && (n < 1900 || n > 2100)) {
        return `Cabin ${bareMatch[1]}`;
      }
    }
  }

  return null;
};


interface BottomDrawerProps {
  packages: { id: number; track_id: string; loc: string }[];
  children?: { visible: boolean; element: ReactNode; styles: any }[];
  isBottomModal: boolean;
  oncloseBottomModal: () => void;
  receipientName: any;
  setReceipientName: any;
  shipName: any;
  setShipName: any;
  divisionName: any;
  setDivisionName: any;
  error: any;
  setError: any;
  location: any;
  setLocation: any;
  setIsNotify: any;
  isNotify: any;
  ocrText: any;
  onAddPackage: () => void;
  setPackageValue: (val: any) => void;
}


const BottomDrawer: React.FC<BottomDrawerProps> = ({
  children,
  packages,
  isBottomModal,
  oncloseBottomModal,
  receipientName,
  setReceipientName,
  ocrText,
  shipName,
  setShipName,
  divisionName,
  setDivisionName,
  location,
  setLocation,
  setIsNotify,
  isNotify,
  error,
  setError,
  onAddPackage,
  setPackageValue,
}) => {
  const insets = useSafeAreaInsets();
  const [activeTab, setActiveTab] = useState('');
  const [visible, setVisible] = useState(false);
  const [ocrshipName, setOcrShipName] = useState<Ships | null>(null);

  const { shipList, user } = usePackageContext();

  console.log('[BottomDrawer] ocrText received:', ocrText);

  useEffect(() => {
    DeviceEventEmitter.addListener('add_package_success', () => {
      setReceipientName(null);
      setDivisionName(null);
      setLocation('');
    });
  }, []);

  useEffect(() => {
    if (!ocrText || !shipList?.length) return;

    const tokens = extractAllTokens(ocrText);
    let foundShip: Ships | null = null;
    let bestScore = 0;

    for (const ship of shipList) {
      const shipNorm = norm(ship.name);
      const shipWords = ship.name.split(/\s+/).map(norm).filter(Boolean);

      for (const token of tokens) {
        const tokenNorm = norm(token);
        const fullScore = editSimilarity(tokenNorm, shipNorm);

        let wordScoreSum = 0;
        for (const sw of shipWords) {
          let best = 0;
          for (const tw of tokenNorm.split(/\s+/)) {
            const s = editSimilarity(sw, tw);
            if (s > best) best = s;
          }
          wordScoreSum += best;
        }
        const wordScore = shipWords.length ? wordScoreSum / shipWords.length : 0;
        const combined = Math.max(fullScore, wordScore);

        if (combined > bestScore && combined >= 0.75) {
          bestScore = combined;
          foundShip = ship;
        }
      }
    }

    if (foundShip) {
      console.log('🚢 Ship matched:', foundShip.name, `(score ${bestScore.toFixed(2)})`);
      setShipName(foundShip);
      setOcrShipName(foundShip);
    } else {
      console.log('❌ No ship found');
    }
  }, [ocrText, shipList]);

  useEffect(() => {
    if (!ocrText || !user) return;

    setReceipientName(null);

    const runSearch = async () => {
      const candidates = extractNameCandidates(ocrText);
      console.log('🔍 Name candidates:', candidates);

      if (!candidates.length) {
        console.log('❌ No name candidates extracted from OCR');
        return;
      }

      let foundRecipient: RecipentObj | null = null;
      let bestScore = 0;

      for (const candidate of candidates) {
        if (candidate.replace(/\s/g, '').length < 4) continue;

        try {
          console.log(`🔎 Searching API: "${candidate}"`);
          const results: RecipentObj[] = await recipientSearchApi(user, encodeURIComponent(candidate));

          if (!results?.length) {
            console.log(`   → 0 results`);
            continue;
          }

          console.log(`   → ${results.length} result(s) returned`);

          const candNorm = norm(candidate);

          for (const rec of results) {
            const first = norm(rec.first_name);
            const last = norm(rec.last_name);

            // 1. Check "First Last"
            const scoreNormal = editSimilarity(candNorm, `${first} ${last}`);

            // 2. Check "Last First" (The fix for your issue)
            const scoreFlipped = editSimilarity(candNorm, `${last} ${first}`);

            // 3. Take the better of the two
            const currentBestScore = Math.max(scoreNormal, scoreFlipped);

            console.log(
              `   → "${rec.first_name} ${rec.last_name}" (Best of flipped/normal) score: ${currentBestScore.toFixed(2)}`,
            );

            if (currentBestScore > bestScore && currentBestScore >= 0.75) {
              bestScore = currentBestScore;
              foundRecipient = rec;
            }
          }

          if (bestScore >= 0.9) {
            console.log('✅ High confidence match, stopping search early');
            break;
          }
        } catch (err) {
          console.log(`   → API error for "${candidate}":`, err);
        }
      }

      if (foundRecipient) {
        console.log(
          `✅ Recipient set: ${foundRecipient.first_name} ${foundRecipient.last_name} (score ${bestScore.toFixed(2)})`,
        );
        setReceipientName(foundRecipient);
      } else {
        console.log('❌ No recipient found across all candidates');
      }
    };

    runSearch();
  }, [ocrText]);


  useEffect(() => {
    if (!ocrText) return;

    const extracted = extractLocation(ocrText);

    if (extracted) {
      console.log('📍 Location extracted:', extracted);
      if (!location) {
        setLocation(extracted);
        setError((prev: any) => ({ ...prev, isLocation: false }));
      }
    } else {
      console.log('❌ No location found in OCR text');
    }
  }, [ocrText]);

  const checkValidation = () => {
    if (!shipName?.name) {
      setError({ ...error, isShipName: true });
      return true;
    } else if (!receipientName) {
      setError({ ...error, isRecipient: true });
      return true;
    } else if (!location) {
      setError({ ...error, isLocation: true });
      return true;
    }
    return false;
  };

  useEffect(() => {
    if (receipientName && shipName) {
      setDivisionName({
        id: receipientName.department_id || 12,
        name: receipientName?.department_name || 'TBD',
      });
      if (receipientName.ship != shipName.name) {
        setError({ ...error, isRecipientBelongsToShip: true });
      } else {
        setError({ ...error, isRecipientBelongsToShip: false });
      }
    } else {
      setError({ ...error, isRecipientBelongsToShip: false });
    }
  }, [receipientName, shipName]);

  return (
    <>
      <ShipListModal
        visible={visible}
        onClose={() => { oncloseBottomModal(); setVisible(false); }}
        activeTab={activeTab}
        getValue={val => {
          if (activeTab === 'Ship') {
            setShipName(val);
            setError({ ...error, isShipName: false });
          } else if (activeTab === 'Rceipient') {
            setReceipientName(val);
            setError({ ...error, isRecipient: false });
          } else if (activeTab === 'Division') {
            setDivisionName(val);
          }
        }}
      />
      <View style={styles.modalContainer}>
        <View style={styles.container}>
          <View style={styles.subContain}>
            <InputPicker
              isPicker={true} isQrCode={false} placeholder={'Ship*'}
              style={{ marginHorizontal: 30, marginTop: 28 }}
              onPickerClick={() => { oncloseBottomModal(); setVisible(true); setActiveTab('Ship'); }}
              onChangeText={() => { }} pickerValue={shipName?.name}
            />
            {error?.isShipName && (
              <Text style={styles.errorMsg}>Please select Ship Name</Text>
            )}

            <InputPicker
              isPicker={true} isQrCode={false} placeholder={'Recipient*'}
              style={{ marginHorizontal: 30, marginTop: 28 }}
              onPickerClick={() => {
                oncloseBottomModal();
                setVisible(true);
                setActiveTab('Rceipient');
                setError({ ...error, isRecipient: false });
              }}
              pickerValue={
                receipientName?.first_name
                  ? receipientName.first_name + ' ' + receipientName.last_name
                  : null
              }
              onChangeText={() => { }}
            />
            {error?.isRecipient && (
              <Text style={styles.errorMsg}>Please select Recipient Name</Text>
            )}
            {error?.isRecipientBelongsToShip && (
              <Text style={styles.errorMsg}>
                The recipient belongs to {receipientName?.ship}
              </Text>
            )}

            <InputPicker
              isPicker={true} disablePicker={true} isQrCode={false}
              placeholder={'Division'}
              style={{ marginHorizontal: 30, marginTop: 28 }}
              onPickerClick={() => { setVisible(true); setActiveTab('Division'); }}
              editable={'false'} pickerValue={divisionName?.name}
              onChangeText={() => { }} hideDropdownButton={true}
            />

            <InputPicker
              isPicker={false} isQrCode={false} placeholder={'Location*'}
              autoCapitalize={'words'} onPickerClick={() => { }}
              pickerValue={location}
              onChangeText={val => {
                setLocation(val);
                setError({ ...error, isLocation: false });
              }}
            />
            {error?.isLocation && (
              <Text style={styles.errorMsg}>Please enter Location</Text>
            )}

            <View style={[styles.roView, { marginTop: isIPad ? 10 : 10 }]}>
              <TouchableOpacity onPress={() => setIsNotify(!isNotify)}>
                {!isNotify ? (
                  <View style={styles.unSelBox} />
                ) : (
                  <View style={styles.selBox}>
                    <Image style={styles.tick} source={IMAGES.check} />
                  </View>
                )}
              </TouchableOpacity>
              <Text style={styles.sendTxt}>Send notification</Text>
            </View>
          </View>

          <View style={{ marginBottom: 10 }}>
            {packages?.length > 0 &&
              packages.map(i => (
                <TouchableOpacity
                  key={i.id}
                  onPress={() => {
                    setPackageValue(i);
                    onAddPackage();
                    __DEV__ && console.log('i', i);
                  }}
                  style={styles.packView}>
                  <Text style={isPad ? styles.packTxtI : styles.packTxt}>
                    Package {i.id}
                  </Text>
                  <View style={styles.rowView}>
                    <Text style={[styles.trTxt, { fontSize: isPad ? 21 : 14 }]}>
                      Tracking ID:{' '}
                      <Text style={[styles.trId, { fontSize: isPad ? 21 : 14 }]}>
                        {sortTrackingNumber(i?.track_id || '')}
                      </Text>
                    </Text>
                  </View>
                </TouchableOpacity>
              ))}
          </View>
        </View>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'space-between' },
  errorMsg: { fontSize: isPad ? 18 : 14, fontFamily: FONTS.PoppinsRegular, color: 'red', marginLeft: 30, marginTop: 5 },
  scrollContent: { flexGrow: 1, backgroundColor: '#fff' },
  input: { color: 'black', fontSize: 14, fontFamily: FONTS.PoppinsRegular },
  subContain: { marginHorizontal: 15, borderRadius: 11, marginTop: 20, paddingBottom: 10, marginBottom: 10 },
  packView: { marginHorizontal: isPad ? 15 : 15, marginTop: isPad ? 20 : 5, backgroundColor: '#F4F4F4', borderRadius: 11, padding: isPad ? 30 : 14 },
  modalContainer: { marginTop: isPad ? 30 : 0, flex: 1, backgroundColor: 'white', borderWidth: 0.2, borderBottomWidth: 0, borderColor: '#80808080', borderTopLeftRadius: 24, borderTopRightRadius: 24 },
  modalContent: { backgroundColor: '#FFFFFF', borderTopLeftRadius: 20, borderTopRightRadius: 20, paddingVertical: 20, paddingHorizontal: 10, paddingBottom: 40 },
  drawerContainer: { width: '100%', flexDirection: 'row', justifyContent: 'space-around', backgroundColor: '#002B45', paddingVertical: 10, borderTopLeftRadius: 20, borderTopRightRadius: 20 },
  button: { flex: 1, marginHorizontal: 10, height: 50, borderRadius: 26, alignItems: 'center', justifyContent: 'center' },
  buttonI: { flex: 1, marginHorizontal: 10, height: 65, borderRadius: 32, alignItems: 'center', justifyContent: 'center' },
  buttonText: { color: '#fff', fontSize: 16, fontFamily: FONTS.PoppinsSemiBold },
  buttonTextI: { color: '#fff', fontSize: 20, fontFamily: FONTS.PoppinsSemiBold },
  direction: { flexDirection: 'row', alignItems: 'center', marginTop: 28, marginHorizontal: 30 },
  trckId: { color: '#989898', fontSize: 14, fontFamily: FONTS.PoppinsRegular, flex: 1 },
  lineView: { marginHorizontal: 30, height: 1, backgroundColor: '#98989850', marginTop: 10 },
  packTxt: { color: 'black', fontSize: 16, fontFamily: FONTS.PoppinsSemiBold },
  packTxtI: { color: 'black', fontSize: 24, fontFamily: FONTS.PoppinsSemiBold },
  rowView: { flexDirection: 'row', alignItems: 'center' },
  trTxt: { flex: 1, color: '#61B3E4', fontSize: 14, fontFamily: FONTS.PoppinsSemiBold },
  trTxt1: { color: '#61B3E4', fontSize: 12, fontFamily: FONTS.PoppinsSemiBold },
  trId: { color: 'black', fontSize: 12, fontFamily: FONTS.PoppinsRegular },
  backView: { alignItems: 'center', justifyContent: 'center', height: screenhight, width: '100%', position: 'absolute', marginTop: 150 },
  roView: { flexDirection: 'row', alignItems: 'center', marginTop: 20, marginHorizontal: 30 },
  unSelBox: { height: isIPad ? 26 : 22, width: isIPad ? 26 : 22, borderRadius: 4, borderWidth: 1, borderColor: '#989898' },
  selBox: { height: isIPad ? 26 : 22, width: isIPad ? 26 : 22, borderRadius: 4, backgroundColor: '#61B3E4', justifyContent: 'center', alignItems: 'center' },
  tick: { height: 9, width: 13, tintColor: 'white' },
  sendTxt: { fontSize: isIPad ? 20 : 16, fontFamily: FONTS.PoppinsRegular, color: 'black', marginLeft: 5 },
});

export { BottomDrawer };